

<?php $__env->startSection('title', 'لوحة التحكم الإدارية - نظام إدارة المخزون'); ?>
<?php $__env->startSection('page-title', 'لوحة التحكم الإدارية'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    نظرة عامة على حالة المخزون
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Logout Button -->
    <form action="/admin/logout" method="POST" style="position: absolute; top: 20px; left: 20px;">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger btn-sm">تسجيل الخروج</button>
    </form>
    
    <!-- KPI Cards -->
    <div class="dashboard-kpis">
        <div class="kpi-card">
            <div class="kpi-number nums"><?php echo e($kpis['totalProducts']); ?></div>
            <div class="kpi-label">إجمالي المنتجات</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-number nums"><?php echo e($kpis['totalWarehouses']); ?></div>
            <div class="kpi-label">إجمالي المخازن</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-number nums"><?php echo e($kpis['belowMinCount']); ?></div>
            <div class="kpi-label">منتجات تحت الحد الأدنى</div>
        </div>
        <div class="kpi-card">
            <div class="kpi-number nums"><?php echo e(number_format($kpis['totalValue'])); ?></div>
            <div class="kpi-label">إجمالي قيمة المخزون</div>
        </div>
    </div>
    
    <!-- Summary Table -->
    <div class="table-container">
        <div class="card-header">
            <div class="card-title">ملخص المخزون حسب المنتج والمخزن</div>
        </div>
        
        <?php if(count($rows) > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>المنتج</th>
                    <th>المخزن</th>
                    <th>المخزون الحالي</th>
                    <th>إجمالي الوحدات</th>
                    <th>الحد الأدنى</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="<?php echo e($row->belowMin ? 'table-row-below-min' : ''); ?>" 
                    data-below-min="<?php echo e($row->belowMin ? 'true' : 'false'); ?>" 
                    data-key="<?php echo e($row->product_name); ?>-<?php echo e($row->warehouse_name); ?>">
                    <td class="table-product-name"><?php echo e($row->product_name); ?></td>
                    <td class="warehouse-name" style="color: var(--primary); font-weight: 600;"><?php echo e($row->warehouse_name); ?></td>
                    <td>
                        <div class="table-stock-info">
                            <div class="table-cartons"><?php echo e($row->closed_cartons); ?> كرتونة</div>
                            <div class="table-units"><?php echo e($row->loose_units); ?> وحدة منفردة</div>
                        </div>
                    </td>
                    <td class="table-cartons nums"><?php echo e(number_format($row->total_units)); ?> وحدة</td>
                    <td class="nums"><?php echo e(number_format($row->min_threshold)); ?> وحدة</td>
                    <td>
                        <?php if($row->belowMin): ?>
                            <span class="status-below-min">تحت الحد الأدنى ⚠️</span>
                        <?php else: ?>
                            <span class="status-ok">مخزون جيد ✅</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state">
            <h3>لا يوجد مخزون</h3>
            <p>لم يتم إضافة أي منتجات أو مخازن بعد</p>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Alert for below minimum items
    const beeped = {};
    const rows = document.querySelectorAll('[data-below-min="true"]');
    
    rows.forEach(row => {
        const key = row.dataset.key;
        if (!beeped[key] && !App.isMuted()) {
            App.playAlert();
            beeped[key] = true;
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\protfolio\inventory system\warehouse-app\resources\views\admin\dashboard-new.blade.php ENDPATH**/ ?>