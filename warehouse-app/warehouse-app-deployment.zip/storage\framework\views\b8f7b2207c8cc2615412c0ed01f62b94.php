<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'نظام إدارة المخزون'); ?></title>
    
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
    <!-- Additional head content -->
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
                <div>
                    <h1><?php echo $__env->yieldContent('page-title', 'نظام إدارة المخزون'); ?></h1>
                    <?php if (! empty(trim($__env->yieldContent('breadcrumb')))): ?>
                        <div class="breadcrumb">
                            <?php echo $__env->yieldContent('breadcrumb'); ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div style="display: flex; align-items: center; gap: 16px;">
                    <!-- Audio Control -->
                    <button class="audio-control" type="button" title="تحكم في الصوت" data-testid="btn-toggle-mute">
                        🔔
                    </button>
                    
                    <?php if(auth()->guard('admin')->check()): ?>
                        <a href="<?php echo e(url('/admin/dashboard')); ?>" class="btn btn-primary btn-sm">
                            لوحة التحكم
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Toast Container -->
    <div class="toast-container"></div>

    <!-- Audio Element -->
    <audio id="alert-audio" preload="none">
        <!-- WebAudio fallback will be used since no actual audio files are provided -->
    </audio>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/selfcheck.js')); ?>" defer></script>
    
    <!-- Additional scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\DELL\Desktop\protfolio\inventory system\warehouse-app\resources\views\layouts\app.blade.php ENDPATH**/ ?>